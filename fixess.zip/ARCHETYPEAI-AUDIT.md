# ArchetypeAI (`shapefuture/ArchetypeAI`) — Audit

**Date:** 2026-10-03 · **Commit:** `397c2707` (main) · **Private repo**
**App:** "Innerverse" — Angular 20 (zoneless) + Firebase + Cloudflare Worker, TypeScript.
**Scope:** dependency health, install reproducibility, CI, Firestore/Worker security posture, repo hygiene.

---

## TL;DR

The application code is in decent shape — **typecheck clean, 691/691 tests pass, production build succeeds.**

The problems are in **dependency/config plumbing and security**, not app logic. Two findings are serious:

1. **Any signed-in user can read any other user's therapy assessment and history.** Privilege escalation in Firestore rules.
2. **`npm ci` cannot install on a clean checkout.** Two independent blockers. And because there is **zero CI**, nobody noticed.

---

## P0 — Firestore authorization bypass

**Any authenticated user can read any other user's full assessment + therapy history.**

These are mental-health / therapy records — special-category personal data under GDPR Art. 9.

### The chain

**Step 1 — `firestore.rules:136-140`** — creating an `adminClients` link requires only being signed in. There is no `isAdmin()` check:

```
match /adminClients/{docId} {
  allow create: if isSignedIn() && request.resource.data.adminUid == request.auth.uid;
```

**Step 2 — `firestore.rules:46-55`** — a link's existence unlocks cross-user reads:

```
match /users/{userId} {
  match /assessment/{docId} {
    allow read: if isOwner(userId)
      || exists(/databases/$(database)/documents/adminClients/$(request.auth.uid + '_' + userId));
  match /history/{docId} {
    allow read: if isOwner(userId)
      || exists(/databases/$(database)/documents/adminClients/$(request.auth.uid + '_' + userId));
```

**Exploit (two calls):**

```js
const db = getFirestore(app);
const attacker = currentUser.uid, victim = '<any victim uid>';

// 1. self-grant a "specialist" link to the victim
await setDoc(doc(db, 'adminClients', `${attacker}_${victim}`),
  { adminUid: attacker, clientUid: victim, notes: '' });

// 2. now read their private records
await getDocs(collection(db, `users/${victim}/assessment`));   // → ALLOWED
await getDocs(collection(db, `users/${victim}/history`));      // → ALLOWED
```

`victim` is discoverable: `publicProfiles` is world-readable to any signed-in user (`firestore.rules:167-178`), and docIds are UIDs.

Note Firestore grant semantics: `allow` clauses are **OR'd, never intersected**, and a parent `match` grant also covers nested paths. The owner-only rule at `:44` therefore does not block the extra read path — it only adds to it.

### P0b — Self-promotion to admin

**`firestore.rules:109-113`**

```
match /adminAllowlist/{email} {
  allow read: if isSignedIn();
  allow create: if isSignedIn();     // ← any user, docId is their own email
  allow update, delete: if isAdmin();
}
```

Any user creates `/adminAllowlist/<own-email>` and `isAdmin()` (`:27-30`) then returns true for them, which gates the allowlist's own update/delete.

`src/services/admin-access.service.ts:6-8` states client-side allowlisting is "a convenience feature, not a security boundary" — correct as far as it goes, but the comments do not state that the **rules make it directly exploitable** rather than merely client-side-cosmetic. The in-code bootstrap email is also hardcoded at `:9`.

### P0c — The test suite cannot catch either

`firestore.rules.spec.ts` **regex-matches the rules file as text.** No emulator, no
`@firebase/rules-unit-testing` — stated plainly at `:25-26`. It asserts the *shape* of
the rules and cannot detect a missing `isAdmin()` gate.

Worse, `:61` pins the vulnerable line as the expected behavior:

```js
expect(body).toMatch(/allow\s+create:\s*if\s+isSignedIn\(\)\s*&&\s*request\.resource\.data\.adminUid\s*==\s*request\.auth\.uid/);
```

This is a regression guard that **locks in the vulnerability**. It will pass while the
app is wide open.

### ✅ PROVEN — `firestore.rules.emulator.spec.ts` (accompanying this report)

The bypass is no longer a reasoned claim. It is **executed against the real Firestore
emulator** and reproduced. The suite asserts the *secure* outcome, so against current
rules it fails — and that failure is the proof:

```
$ npm run test:rules
Tests  10 failed | 11 passed (21)
```

**Failing — vulnerability confirmed exploitable:**

| Test | Result |
|---|---|
| denies a non-admin from creating an adminClients link to another user | × **allowed** |
| denies reading a victim assessment after self-granting a link | × **allowed** |
| denies reading a victim history after self-granting a link | × **allowed** |
| denies listing a victim collection after self-granting a link | × **allowed** |
| denies a user inserting themselves into the admin allowlist | × **allowed** |
| denies a non-admin granting themselves another user allowlist entry | × **allowed** |
| denies unauthenticated writes to pushTokens | × **allowed** |
| denies unauthenticated writes to telemetryResponses | × **allowed** |
| denies a user attaching themselves to an arbitrary therapist | × **allowed** |
| denies inserting into therapistClients without a genuine link | × **allowed** |

**Passing — already correct, keep it that way:** all 8 `[BASELINE]` tests (owner reads
own data, cross-user writes denied, unauthenticated denied, profile/share-code
ownership) and, importantly, **the genuine specialist-dashboard flow still works** —
so fixing the bypass does not require breaking the product. One extra assertion
confirms the rules already correctly block a user from impersonating a therapist
against a victim.

### Two corrections to the earlier draft

- `clientShares` is **less severe** than first reported. The rule requires
  `clientUid == request.auth.uid`, so a user cannot impersonate a therapist to read
  someone else's data — that direction is properly denied. What is possible is
  binding yourself to an arbitrary `therapistUid` (roster injection), not
  exfiltration. Both directions are now asserted.
- `therapistClients` allows self-insertion into a therapist roster, but no rule keys
  an `exists()` off it, so it grants **no** access to client data. Moderate, not P0.

### Fix

Gate every privileged write on a real admin check, and move admin status to **Firebase custom claims** (the repo's own comments already call this out as the right answer):

```
function isAdmin() {
  return isSignedIn() && request.auth.token.admin == true;
}

match /adminClients/{docId} {
  allow create: if isAdmin() && request.resource.data.adminUid == request.auth.uid;
  ...
}
match /adminAllowlist/{email} {
  allow read: if isAdmin();
  allow create: if isAdmin() && request.auth.token.email == email;
  ...
}
```

Then rewrite the rules test against the emulator. A text-matching test on a security file is worse than no test.

---

## P1 — `npm ci` cannot install on a clean checkout

**THREE independent failures**, not two. npm reports them one at a time, so fixing
the first exposes the second — dependency whack-a-mole. All three are confirmed and
the full set is fixed in the accompanying patch.

### 1. ERESOLVE — zone.js peer conflict

```
Found: zone.js@0.16.1        (package.json pins ^0.16.1)
Could not resolve dependency:
  peerOptional zone.js@"~0.15.0" from @angular/core@20.3.18
```

**Fix: pin `zone.js` to `~0.15.0`** (resolves to 0.15.1) and commit the regenerated lockfile.

> ⚠️ **Correction.** An earlier draft of this audit recommended *deleting* `zone.js`
> entirely, on the theory that a zoneless app does not need it. **That is wrong, and
> the test suite proves it** — removing the imports from `src/test.ts` breaks
> **94 of 691 tests**. `getTestBed().initTestEnvironment(BrowserDynamicTestingModule, …)`
> is the zone-based testing platform; change detection in tests depends on zone.js.
> The `NG0914` warnings are cosmetic. Downgrading the pin is the correct fix.
> Making the test platform zoneless is a worthwhile *separate* refactor, not a
> drive-by dependency fix.

### 2. EBADPLATFORM — macOS-only dependency

```
notsup Unsupported platform for @rollup/rollup-darwin-x64@4.59.0:
  wanted {"os":"darwin","cpu":"x64"} (current: {"os":"linux","cpu":"x64"})
```

**Fix: delete `@rollup/rollup-darwin-x64`** from devDependencies. It is a platform-
specific Rollup binary that does not belong in a manifest at all — Rollup resolves
the correct native package per-platform via optionalDependencies.

### 3. ERESOLVE — Cloudflare workers-types (masked by #1)

Only surfaced once #1 was fixed:

```
While resolving: wrangler@4.127.1
Found: @cloudflare/workers-types@4.20260413.1
Could not resolve dependency:
  peerOptional @cloudflare/workers-types@"^5.20260828.1" from wrangler@4.127.1
```

**Fix: bump `@cloudflare/workers-types` to `^5.20260828.1`** (resolves to 5.20261003.1).

### Verified

With all three applied and `package-lock.json` regenerated:

```
$ npm ci          → exit 0, 1349 packages, no flags
$ npm test        → 675 passed (41 files) + 21 skipped
$ npm run build   → exit 0
$ npm run test:rules → 10 failed | 11 passed   ← the bypass, demonstrated
```


### P1b — Zero CI, which is why this survived

`/repos/shapefuture/ArchetypeAI/actions/workflows` → `total_count: 0`
`/repos/shapefuture/ArchetypeAI/actions/runs` → `total_count: 0`
No `.github/` directory in the tree.

Nothing has ever been verified on a non-macOS machine. The macOS-only Rollup pin, the darwin `codesign` postinstall (`scripts/sign-native-addons.mjs`), and the zone.js conflict are all consistent with a project that has only ever been built on one laptop.

**Add a workflow:** Linux runner → `npm ci` → `tsc --noEmit` → `vitest run` → `ng build`. That alone would have caught both blockers.

---

## P1 — Cloudflare Worker: open, unmetered, unauthenticated

### Reflected CORS with no allowlist — `worker.ts:10-11`

```js
function corsHeaders(request) {
  return { ...AI_CORS, 'Access-Control-Allow-Origin': request.headers.get('Origin') ?? '*' };
}
```

Any site can call any endpoint. Also missing `Vary: Origin`, so a shared cache can serve one origin's headers to another.

### Unauthenticated, unmetered AI proxy — `worker.ts:44`

`/api/ai` has no auth and no rate limit. Anyone can POST arbitrary prompts and burn the `OPENROUTER_API_KEY` / `OLLAMA_API_KEY` / `NVIDIA_API_KEY` budget. `/api/gemini` (`:133`) is the same.

### Therapy prompts written to edge logs — `worker.ts:76`

```js
console.log(`[AI] Prompt: "${String(body.prompt ?? '').substring(0, 80)}..."`);
```

The first 80 chars of mental-health prompts persisted to Cloudflare logs. On a therapy product this is a data-protection problem, not just noise.

### Open redirect in the payment flow — `worker.ts:125`, `:179-192`

`/api/stripe-checkout` is unauthenticated and builds redirect URLs from a client-supplied `origin`:

```js
const origin = body.origin || request.headers.get('Origin');
params.set('success_url', `${origin}/?stripe=success&session_id=...`);
params.set('cancel_url',  `${origin}/?stripe=cancel`);
```

An attacker hosts a page that calls the endpoint with `origin: "https://evil.example"`, producing a **genuine Stripe-hosted checkout** whose success/cancel redirects to their domain — a credible phishing vector on a real payment.

**Fix:** server-side origin allowlist; validate `body.origin` against it before building URLs; add auth + rate limiting to `/api/ai`; stop logging prompt content.

---

## P2 — Additional Firestore rule gaps

| Location | Issue |
|---|---|
| `firestore.rules:80-83` | `pushTokens` create has **no auth check at all** — unauthenticated write |
| `firestore.rules:73-77` | `telemetryResponses` create has **no auth check** |
| `firestore.rules:182-185` | `therapists/{uid}` → `allow read: if true` — public unauthenticated read; confirm no PII in those docs |
| `firestore.rules:219-221` | `clientShares` create trusts self-asserted `source == 'booking'`; never checked against a real `appointments` doc — a fake "therapist" link can be self-issued |
| `firestore.rules:195-197` | `appointments` create constrains `clientUid`/`status` but permits arbitrary extra fields |
| `firestore.rules:91-97` | `shareCodes` readable by any signed-in user — enumeration of codes may be possible |

---

## P2 — Repository hygiene

69 MB working tree, and a meaningful share of it is scratch:

- **115 Playwright page dumps** committed in `.playwright-cli/` (1.5 MB) + `.playwright-mcp/`
- **4 near-duplicate scratch dirs**: `design/kawaii-sticker-character-design`, `(1)`, `(2)`, `(3)` — names contain spaces and parens
- **29 stray screenshots/binaries at repo root** (~8.4 MB): `fix-break.jpg`, `new-coach.jpg`, `cur-universe.jpg`, …
- **`zero-r_partsmap_v3_1.zip` committed**
- **None of it is in `.gitignore`** — it only covers logs, `node_modules`, `dist`, `.beads`, `.angular`, and three specific scratch filenames
- 47 `.md` planning docs at root, including three `*_OVERHAUL_PLAN*` files
- Raw text source books committed: `DNMS Book2020.txt`, `Manual - Experiential Therapy Handbook.txt`

Repo is 0 stars / 0 watchers, created 2026-08-15, last push today, 1 PR merged. History rewrite is cheap right now if you want the tree clean.

---

## P2 — No bundle budgets

`angular.json` contains **no `budgets` configuration whatsoever** — nothing fails the build on bundle growth.

Current production build: **2.75 MB initial raw / 528 KB transfer**, with `chunk-HB6FCKTC.js` at 1.11 MB and `main` at 898 KB. Heavy for a mobile PWA, and nothing is watching it.

(`sourceMap: true` is correctly scoped to the `development` configuration only — no leak into production.)

---

## P3 — Minor

- **Duplicated test stacks.** Karma + Jasmine *and* Vitest are both configured; only Vitest runs. `karma.conf.cjs`, `karma-*` and `@types/jasmine` devDeps are dead weight, and `tsconfig.json:13-16` declares `types: ["node", "jasmine"]` for a runner that never executes.
- **Angular patch drift.** `@angular/core@20.3.18` vs `@angular/build@20.3.23` resolved from the same `^20.2.0` range.
- **`@types/dompurify` sits in `dependencies`**, not `devDependencies`.
- `.nvmrc` pins Node 20.19.1; Node 22 also works, but nothing enforces the pin.

---

## Verification notes

**Reproduced end-to-end on Linux.** Install fixes verified with a clean `npm ci` (exit 0, no flags); typecheck exit 0; 675/675 unit tests pass; `ng build` exit 0. The security suite was executed against a real Firestore emulator (OpenJDK 17 + `cloud-firestore-emulator-v1.19.8.jar`).

**Method note:** source obtained via the GitHub tarball API, not `git clone` — this
sandbox's `git` cannot validate its egress proxy's TLS certificate, and I was not
going to disable verification to move a `repo`/`admin:org` token, so I used `curl`.
Consequence: `scripts/stamp-sw.mjs` could not read a git SHA and fell back to a random
build id. **That is an artifact of the tarball checkout, not a repo defect** — but it
means the service-worker build id is unverifiable here, so the SW update flow was not
fully validated.

**An earlier draft claimed independent verification of the P0 finding. That did not
happen** — the verification subagent returned no output. I have since replaced
reasoning with execution: the bypass is now demonstrated by the emulator suite, which
is stronger evidence than a second reader.

**Two of my own recommendations were wrong and are corrected above:** deleting
`zone.js` (breaks 94 tests), and overstating `clientShares` as an exfiltration path.
Both were caught by running the code rather than trusting the reading.
