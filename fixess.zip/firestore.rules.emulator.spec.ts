import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import {
  assertFails,
  assertSucceeds,
  initializeTestEnvironment,
  type RulesTestEnvironment,
} from '@firebase/rules-unit-testing';
import { collection, doc, getDoc, getDocs, setDoc } from 'firebase/firestore';

/**
 * Executable security regression test for `firestore.rules`.
 *
 * WHY THIS FILE EXISTS
 * --------------------
 * `firestore.rules.spec.ts` regex-matches the rules file as *text* — it never
 * executes them (see its own header, lines 25-26). It therefore cannot detect
 * a missing authorization gate, and in fact pins the vulnerable `adminClients`
 * create rule as the expected shape (that file, line 61). A text-matching test
 * on a security file is worse than no test: it reports green while the app is
 * open.
 *
 * This file actually RUNS the rules against the Firestore emulator
 * (`@firebase/rules-unit-testing`) and asserts the behaviour the product
 * intends. Every test below is written as an ASSERTION OF THE SECURE OUTCOME.
 * Against the current rules these FAIL — that failure IS the vulnerability,
 * demonstrated rather than asserted.
 *
 * ---------------------------------------------------------------------------
 * THE VULNERABILITY BEING DEMONSTRATED
 * ---------------------------------------------------------------------------
 * Two rules combine into a complete authorization bypass:
 *
 *   1. firestore.rules:140 — `adminClients` create requires only `isSignedIn()`:
 *        allow create: if isSignedIn() && request.resource.data.adminUid == request.auth.uid;
 *      There is no `isAdmin()` check, so any authenticated user can mint a
 *      "specialist → client" link pointing at anyone.
 *
 *   2. firestore.rules:47-48, 52-53 — the mere EXISTENCE of that link unlocks
 *      cross-user reads:
 *        allow read: if isOwner(userId)
 *          || exists(/databases/$(database)/documents/adminClients/$(request.auth.uid + '_' + userId));
 *
 *   Chain: create `adminClients/{attacker}_{victim}` → read
 *   `users/{victim}/assessment/*` and `users/{victim}/history/*`.
 *   That is another user's therapy data.
 *
 *   Second, independent escalation — firestore.rules:111:
 *        allow create: if isSignedIn();   // on /adminAllowlist/{email}
 *   Any user can create their own allowlist entry (docId == their email), after
 *   which the `isAdmin()` helper (lines 27-30) returns true for them.
 *
 *   Note on Firestore semantics: `allow` grants are OR'd, never intersected,
 *   and a parent `match` grant also applies to nested paths. The owner-only
 *   rule at line 44 therefore does NOT block these reads — it only adds to them.
 *
 * ---------------------------------------------------------------------------
 * HOW TO RUN
 * ---------------------------------------------------------------------------
 *   npm run test:rules
 *
 * which shells out to `firebase emulators:exec` (the emulator needs a JVM; the
 * suite skips itself cleanly when FIRESTORE_EMULATOR_HOST is absent, so plain
 * `npm test` is unaffected).
 *
 * EXPECTED RESULT ON `main` TODAY: the tests marked [EXPLOIT] fail. That is
 * the point — do not "fix" them by weakening the assertions. Fix `firestore.rules`.
 */

const RULES_PATH = resolve(__dirname, 'firestore.rules');
const RULES = readFileSync(RULES_PATH, 'utf-8');

const EMULATOR = !!process.env.FIRESTORE_EMULATOR_HOST;
const UIDS = {
  attacker: 'uid_attacker',
  victim: 'uid_victim',
  admin: 'uid_admin',
  therapist: 'uid_therapist',
} as const;

let testEnv: RulesTestEnvironment;

beforeAll(async () => {
  testEnv = await initializeTestEnvironment({
    projectId: 'demo-archetypeai',
    firestore: { rules: RULES },
  });
});

afterAll(async () => {
  await testEnv?.cleanup();
});

beforeEach(async () => {
  await testEnv.clearFirestore();
});

/** A Firestore handle acting as `uid`, optionally carrying an `email` token claim. */
function asUser(uid: string, email?: string) {
  return email
    ? testEnv.authenticatedContext(uid, { email }).firestore()
    : testEnv.authenticatedContext(uid).firestore();
}

function asAnon() {
  return testEnv.unauthenticatedContext().firestore();
}

/** Seed data with rules switched off, so fixtures are never blocked. */
async function seed(fn: (db: FirebaseFirestore.Firestore) => Promise<void>) {
  await testEnv.withSecurityRulesDisabled(async (ctx) => {
    await fn(ctx.firestore());
  });
}

async function seedVictimRecords() {
  await seed(async (db) => {
    await setDoc(doc(db, 'users', UIDS.victim, 'assessment', 'current'), {
      answers: { mwt: 'grief', shadow: 'abandonment' },
      at: '2026-10-01T00:00:00.000Z',
    });
    await setDoc(doc(db, 'users', UIDS.victim, 'history', 'h1'), {
      at: '2026-09-01T00:00:00.000Z',
      note: 'session summary',
    });
  });
}

describe.skipIf(!EMULATOR)('firestore.rules — executed against the Firestore emulator', () => {
  // -------------------------------------------------------------------------
  // [EXPLOIT] The core bypass: two calls, full read of another user's records.
  // -------------------------------------------------------------------------
  describe('[EXPLOIT] cross-user data exfiltration', () => {
    it('denies a non-admin from creating an adminClients link to another user', async () => {
      const attacker = asUser(UIDS.attacker, 'attacker@example.com');

      // Rule 140 currently allows this: isSignedIn() && adminUid == self.
      await assertFails(
        setDoc(doc(attacker, 'adminClients', `${UIDs.attacker}_${UIDS.victim}`), {
          adminUid: UIDS.attacker,
          clientUid: UIDS.victim,
          notes: '',
        }),
      );
    });

    it('denies reading a victim assessment after self-granting a link', async () => {
      await seedVictimRecords();
      const attacker = asUser(UIDS.attacker, 'attacker@example.com');

      // Step 1 — mint the link (currently succeeds).
      await setDoc(doc(attacker, 'adminClients', `${UIDS.attacker}_${UIDs.victim}`), {
        adminUid: UIDS.attacker,
        clientUid: UIDS.victim,
        notes: '',
      });

      // Step 2 — the exfiltration. Rules 47-48 currently allow this.
      await assertFails(getDoc(doc(attacker, 'users', UIDS.victim, 'assessment', 'current')));
    });

    it('denies reading a victim history after self-granting a link', async () => {
      await seedVictimRecords();
      const attacker = asUser(UIDS.attacker, 'attacker@example.com');

      await setDoc(doc(attacker, 'adminClients', `${UIDs.attacker}_${UIDs.victim}`), {
        adminUid: UIDS.attacker,
        clientUid: UIDS.victim,
        notes: '',
      });

      // Rules 52-53 currently allow this.
      await assertFails(getDoc(doc(attacker, 'users', UIDS.victim, 'history', 'h1')));
    });

    it('denies listing a victim collection after self-granting a link', async () => {
      await seedVictimRecords();
      const attacker = asUser(UIDS.attacker, 'attacker@example.com');

      await setDoc(doc(attacker, 'adminClients', `${UIDs.attacker}_${UIDs.victim}`), {
        adminUid: UIDS.attacker,
        clientUid: UIDS.victim,
        notes: '',
      });

      await assertFails(getDocs(collection(attacker, 'users', UIDS.victim, 'assessment')));
    });
  });

  // -------------------------------------------------------------------------
  // [EXPLOIT] Self-promotion to administrator.
  // -------------------------------------------------------------------------
  describe('[EXPLOIT] privilege escalation via adminAllowlist', () => {
    it('denies a user inserting themselves into the admin allowlist', async () => {
      const attacker = asUser(UIDS.attacker, 'attacker@example.com');

      // Rule 111 currently allows this: allow create: if isSignedIn();
      await assertFails(
        setDoc(doc(attacker, 'adminAllowlist', 'attacker@example.com'), {
          email: 'attacker@example.com',
          createdAt: new Date().toISOString(),
          createdByUid: UIDS.attacker,
        }),
      );
    });

    it('denies a non-admin granting themselves another user allowlist entry', async () => {
      const attacker = asUser(UIDS.attacker, 'attacker@example.com');

      // Even if the docId is not their own email, there must be an admin gate.
      await assertFails(
        setDoc(doc(attacker, 'adminAllowlist', 'someone-else@example.com'), {
          email: 'someone-else@example.com',
          createdAt: new Date().toISOString(),
          createdByUid: UIDS.attacker,
        }),
      );
    });

    it('denies an unauthenticated user creating an allowlist entry', async () => {
      await assertFails(
        setDoc(doc(asAnon(), 'adminAllowlist', 'ghost@example.com'), {
          email: 'ghost@example.com',
          createdAt: new Date().toISOString(),
          createdByUid: null,
        }),
      );
    });
  });

  // -------------------------------------------------------------------------
  // [EXPLOIT] Unauthenticated writes to user-facing collections.
  // -------------------------------------------------------------------------
  describe('[EXPLOIT] missing authentication checks', () => {
    it('denies unauthenticated writes to pushTokens', async () => {
      // Rules 80-83: `allow create` has no isSignedIn() guard.
      await assertFails(
        setDoc(doc(asAnon(), 'pushTokens', 'attacker-controlled-token'), {
          token: 'attacker-controlled-token',
          createdAt: new Date().toISOString(),
        }),
      );
    });

    it('denies unauthenticated writes to telemetryResponses', async () => {
      // Rules 73-77: `allow create` has no isSignedIn() guard.
      await assertFails(
        setDoc(doc(asAnon(), 'telemetryResponses', 'flood-1'), {
          payload: 'x'.repeat(64_000),
          at: new Date().toISOString(),
        }),
      );
    });
  });

  // -------------------------------------------------------------------------
  // [EXPLOIT] Forged "specialist" relationships.
  // -------------------------------------------------------------------------
  describe('[EXPLOIT] forged therapist/client links', () => {
    it('denies a user attaching themselves to an arbitrary therapist', async () => {
      const attacker = asUser(UIDS.attacker, 'attacker@example.com');

      // Rules 219-221 require `clientUid == request.auth.uid`, so a user
      // CANNOT impersonate a therapist to read someone else's data — that
      // direction is correctly blocked (this test asserts it below). What IS
      // currently allowed is the reverse: binding yourself to ANY
      // therapistUid with a self-asserted `source: 'booking'` that is never
      // checked against a real `appointments` document. That is roster
      // injection, not exfiltration — lower severity than first assumed.
      await assertFails(
        setDoc(doc(attacker, 'clientShares', `${UIDS.therapist}_${UIDS.attacker}`), {
          clientUid: UIDS.attacker,
          therapistUid: UIDS.therapist,
          source: 'booking',
        }),
      );
    });

    it('denies impersonating a therapist to claim a victim as a client', async () => {
      const attacker = asUser(UIDS.attacker, 'attacker@example.com');

      // The genuinely dangerous direction, asserted so a future rules edit
      // cannot open it. Verified to PASS on current rules.
      await assertFails(
        setDoc(doc(attacker, 'clientShares', `${UIDS.attacker}_${UIDS.victim}`), {
          clientUid: UIDS.victim,
          therapistUid: UIDS.attacker,
          source: 'booking',
        }),
      );
    });

    it('denies inserting into therapistClients without a genuine link', async () => {
      const attacker = asUser(UIDS.attacker, 'attacker@example.com');

      // Rules 236-238 let either party create the link; therapistUid == self
      // satisfies it, so anyone can appear as a therapist with any client.
      await assertFails(
        setDoc(doc(attacker, 'therapistClients', `${UIDS.attacker}_${UIDS.victim}`), {
          therapistUid: UIDS.attacker,
          clientUid: UIDS.victim,
        }),
      );
    });
  });

  // -------------------------------------------------------------------------
  // [BASELINE] Legitimate flows that MUST keep working after a rules fix.
  // These guard against "fixing" the bypass by breaking the product.
  // -------------------------------------------------------------------------
  describe('[BASELINE] legitimate flows must keep working', () => {
    it('allows a user to read their own assessment', async () => {
      await seedVictimRecords();
      await assertSucceeds(
        getDoc(doc(asUser(UIDS.victim, 'victim@example.com'), 'users', UIDS.victim, 'assessment', 'current')),
      );
    });

    it('allows a user to write their own assessment', async () => {
      const victim = asUser(UIDS.victim, 'victim@example.com');
      await assertSucceeds(
        setDoc(doc(victim, 'users', UIDS.victim, 'assessment', 'current'), {
          answers: { mwt: 'joy' },
          at: new Date().toISOString(),
        }),
      );
    });

    it('allows a user to read their own history', async () => {
      await seedVictimRecords();
      await assertSucceeds(
        getDoc(doc(asUser(UIDS.victim, 'victim@example.com'), 'users', UIDS.victim, 'history', 'h1')),
      );
    });

    it('denies a user writing to another user tree', async () => {
      await seedVictimRecords();
      await assertFails(
        setDoc(doc(asUser(UIDS.attacker, 'a@example.com'), 'users', UIDS.victim, 'assessment', 'forged'), {
          answers: {},
          at: new Date().toISOString(),
        }),
      );
    });

    it('denies unauthenticated access to user data', async () => {
      await seedVictimRecords();
      await assertFails(getDoc(doc(asAnon(), 'users', UIDS.victim, 'assessment', 'current')));
    });

    it('allows a user to manage their own public profile', async () => {
      const victim = asUser(UIDS.victim, 'victim@example.com');
      await assertSucceeds(
        setDoc(doc(victim, 'publicProfiles', UIDS.victim), {
          emailLower: 'victim@example.com',
          displayName: 'Vic',
        }),
      );
    });

    it('denies overwriting another user public profile', async () => {
      await seed(async (db) => {
        await setDoc(doc(db, 'publicProfiles', UIDS.victim), {
          emailLower: 'victim@example.com',
          displayName: 'Vic',
        });
      });
      await assertFails(
        setDoc(doc(asUser(UIDS.attacker, 'a@example.com'), 'publicProfiles', UIDS.victim), {
          emailLower: 'victim@example.com',
          displayName: 'Impostor',
        }),
      );
    });

    it('allows a user to create their own share code', async () => {
      const victim = asUser(UIDS.victim, 'victim@example.com');
      await assertSucceeds(
        setDoc(doc(victim, 'shareCodes', 'CODE123'), { uid: UIDS.victim }),
      );
    });
  });

  // -------------------------------------------------------------------------
  // [BASELINE] The specialist flow the rules were written FOR. Under the
  // proposed fix (isAdmin() via custom claims) this must still pass. It fails
  // today only because custom claims are not implemented yet — that is the
  // target state, not a regression.
  // -------------------------------------------------------------------------
  describe('[BASELINE] legitimate specialist dashboard flow', () => {
    it('allows a genuine admin to create and read a client link', async () => {
      await seedVictimRecords();
      // A real deployment sets this claim server-side via the Admin SDK.
      // Until then, allowlist membership stands in for it so the rules can be
      // exercised — see the migration note in the audit.
      await seed(async (db) => {
        await setDoc(doc(db, 'adminAllowlist', 'admin@example.com'), {
          email: 'admin@example.com',
          createdAt: new Date().toISOString(),
          createdByUid: null,
        });
      });

      const admin = asUser(UIDS.admin, 'admin@example.com');
      await assertSucceeds(
        setDoc(doc(admin, 'adminClients', `${UIDS.admin}_${UIDS.victim}`), {
          adminUid: UIDS.admin,
          clientUid: UIDS.victim,
          notes: '',
        }),
      );
      await assertSucceeds(
        getDoc(doc(admin, 'users', UIDS.victim, 'assessment', 'current')),
      );
    });
  });
});
