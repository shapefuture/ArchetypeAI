import { defineConfig } from 'vitest/config';

/**
 * Dedicated Vitest config for the Firestore security-rules suite.
 *
 * Deliberately does NOT use `src/test.ts` as a setup file. That bootstrap is
 * Angular's TestBed initialiser and drags in `zone.js` + `zone.js/testing` —
 * neither of which a rules test needs, and both of which are the source of the
 * dependency conflict described in the audit. Keeping the suites separate means
 * the security tests cannot be broken by (or break) the Angular test harness.
 */
export default defineConfig({
  test: {
    environment: 'node',
    globals: true,
    include: ['firestore.rules.emulator.spec.ts'],
    // The emulator host is injected by `firebase emulators:exec`.
    testTimeout: 20_000,
    hookTimeout: 60_000,
  },
});
