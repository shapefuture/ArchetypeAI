# Parts Cartographer — IFS map PWA

Installable Progressive Web App for **Internal Family Systems (IFS)** work: a living cartography of your inner system — parts, burdens, resources, polarizations — with assessment, 3D inner universe, AI coaching, practice library, check-ins (JITAI) and compatibility (synastry) analysis.

> Re-skin of the pattern-app architecture (no router, one `appState` signal + `@switch`), restyled after the *cutebuttons* UI kit (Titan One / Fredoka / Nunito, chunky 3D buttons, plush characters) and re-themed from astrology to IFS parts work.

## Run

```bash
npm install
npm run dev        # Vite dev server → http://localhost:5174
npm run build      # vite build + stamp dist/sw.js from dist/index.html hash
npm run preview    # preview the production build (no-store headers)
```

## What's inside

| Area | Notes |
|---|---|
| **State machine** | single `state` signal in `src/app.jsx`; screens under `src/screens/`; the three.js canvas (`#universe-host`) lives **outside** the switch — leaving the universe only calls `sleep()` for instant re-entry; renderer chunk (`services/universe-scene.ts`) is dynamically imported on first entry and prefetched on Sky hover |
| **Dock** | Intro owns Base / Sky / Code× / You + center FAB (start test, respects weekly gate) |
| **Assessment** | ethics consent → somatic per-part input (intensity 1–7 + felt) → 3 future-self statements → `scoreSystem` → ScoredProfile |
| **Descent** | 4-layer understanding cycle · chemistry · save/reset/delete (sealed verdict resurfaces later — JITAI) |
| **Results** | constellation headline + essay, Self-energy radar, polarizations/complexes/subtypes, attachment/need-hunger/leaks, history, notes, specialist area |
| **Cabinet** | family filters (Managers / Firefighters / Exiles / Resources), part sheets, plush editor (shape/eyes/mouth/color/family), add card, crests, ⚗️ chemistry |
| **Innerverse** | 3D universe w/ raycast pick, search + summon, filters drawer (4 dims + cluster toggles), Archetype Studio (AI), coach, backup, synastry, compare tray |
| **Overlays** | coach (streaming chat, general↔parts modes), help (7 items, auto-opens first visit), install prompt (auto once/week after 9s), synastry, practice (20 exercises · 5 chapters · 3 gates · rehearsal timer), check-in (arousal → event → predicted part → sealed verdict, blame/license sliders, charter, push opt-in), quickscan, therapist booking wizard, login (Google/email/anonymous linking), map-gate, paywall, renderer-fail |
| **Billing** | Stripe-style checkout + verify, USD/RUB monthly · yearly · one-time lifetime, restore |
| **i18n** | single EN/RU source `src/i18n/strings.ts` + language & dark/light switches in You tab |
| **Core ports** | `src/core/ports.ts` — storage, auth (anonymous bootstrap @4s, Google popup, email, UID-preserving link), AI (Gemini worker / local heuristic / resilient with degradation descriptor), billing |
| **Scoring** | `scoring-v2.ts` (parts, resources + leaks, self-energy radar, burden, constellation, subtypes, polarizations, attachment, complexes, need hunger, coping stack, validity, crisis flag), `synastry-v2.ts`, local telemetry (item distributions, local-only) |
| **PWA** | `public/manifest.webmanifest`, `public/sw.js` (stamped by `scripts/stamp-sw.mjs`), no-store headers on shell routes, PNG icons (any + maskable), standalone display, shortcuts `?go=assessment \| ?go=checkin \| ?go=universe` |

## Verification

- `npx vite build` — clean production build (three.js isolated to a lazy `universe-scene` chunk)
- `pattern-app/ifs-smoke.mjs` — Playwright smoke: loading → onboarding → 4 tabs → map gate → 3D universe + auto-help → cabinet → part sheet/editor → full assessment → results tabs → descent layers → chemistry → coach/check-in/practice/synastry/quickscan/paywall/login overlays → RU switch → light mode → therapist → **0 console/page errors**, 27 shots in `/home/user/ifs-shots/`.

## Structure

```
src/
  app.jsx            # state machine, dock, universe host, overlay/sheet switches
  overlays.jsx       # all 11 overlay components
  screens/           # landing, cabinet(+sheet/editor/chemistry/charter), assessment(+gate/descent/results), innerverse(+specialist)
  core/              # ports, local-store, auth, ai adapters, billing, scoring-v2, synastry-v2, telemetry
  pal/               # plush Character + traits (ported from cutebuttons), sfx
  i18n/strings.ts    # EN/RU single source
  services/universe-scene.ts  # three.js universe (lazy chunk)
  ui/ui.jsx          # StatusBar, Crest, Radar, Bars, Sheet, Seg, Steps, Ico, Price, Confetti, Tap
public/              # manifest, sw.js, icons (192/512/maskable)
scripts/stamp-sw.mjs # post-build SW cache-bust stamp
```
