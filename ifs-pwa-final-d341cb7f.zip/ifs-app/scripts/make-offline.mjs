/* make-offline.mjs — inline the whole built PWA into ONE self-contained HTML.
   Works from file:// with zero network: CSS+JS+fonts+icons inline, dynamic
   chunks (universe-scene, sfx) rewritten to data: module imports. */
import { readFileSync, writeFileSync, existsSync, readdirSync, statSync } from 'node:fs';
import { join, dirname } from 'node:path';

const DIST = join(process.cwd(), 'dist');
const OUT = join(process.cwd(), 'preview-offline.html');

const MIME = { '.woff2': 'font/woff2', '.woff': 'font/woff', '.png': 'image/png', '.jpg': 'image/jpeg', '.svg': 'image/svg+xml', '.webmanifest': 'application/manifest+json' };
const dataUri = (file) => {
  const ext = file.slice(file.lastIndexOf('.'));
  return `data:${MIME[ext] ?? 'application/octet-stream'};base64,${readFileSync(file).toString('base64')}`;
};
const resolveAsset = (ref) => {
  const clean = ref.replace(/^\//, '').replace(/^\.\//, '');
  const p = join(DIST, clean);
  if (existsSync(p)) return p;
  // import("./chunk.js") lives next to the main bundle in dist/assets
  const alt = join(DIST, 'assets', clean.replace(/^assets\//, ''));
  if (existsSync(alt)) return alt;
  return null;
};

let html = readFileSync(join(DIST, 'index.html'), 'utf8');
let inlined = { css: 0, js: 0, chunks: 0, fonts: 0, icons: 0 };

/* 1 ── CSS: inline fonts, then embed the stylesheet */
html = html.replace(/<link\s+rel="stylesheet"[^>]*href="([^"]+)"[^>]*>/g, (m, href) => {
  const file = resolveAsset(href);
  if (!file) throw new Error('css not found: ' + href);
  let css = readFileSync(file, 'utf8');
  css = css.replace(/url\((['"]?)([^'")]+)\1\)/g, (m2, q, ref) => {
    if (ref.startsWith('data:') || ref.startsWith('#') || ref.startsWith('%')) return m2;
    if (!/\.(woff2?|ttf|otf|png|jpe?g|svg|webmanifest)(\?|#|$)/i.test(ref)) return m2;
    const f = resolveAsset(ref);
    if (!f) throw new Error('css asset not found: ' + ref);
    inlined.fonts++;
    return `url(${dataUri(f)})`;
  });
  inlined.css++;
  return `<style data-inlined="css">\n${css}\n</style>`;
});

/* 2 ── dynamic chunks → data: module imports (universe-scene, sfx, …) */
const inlineChunks = (code) => code.replace(/import\((["'])([^"'()]+)\1\)/g, (m, q, spec) => {
  if (spec.startsWith('data:') || spec.startsWith('blob:')) return m;
  const f = resolveAsset(spec);
  if (!f) { console.warn('  ! chunk not found, left as-is:', spec); return m; }
  inlined.chunks++;
  return `import("data:text/javascript;base64,${readFileSync(f).toString('base64')}")`;
});

/* 3 ── main bundle: inline as module script */
html = html.replace(/<script\s+type="module"[^>]*src="([^"]+)"[^>]*><\/script>/g, (m, src) => {
  const file = resolveAsset(src);
  if (!file) throw new Error('main js not found: ' + src);
  const code = inlineChunks(readFileSync(file, 'utf8'));
  inlined.js++;
  return `<script type="module" data-inlined="main">\n${code}\n</script>`;
});

/* 4 ── modulepreloads are pointless now */
html = html.replace(/<link\s+rel="modulepreload"[^>]*>/g, '');

/* 5 ── manifest + icons → data URIs */
html = html.replace(/<link\s+rel="manifest"[^>]*href="([^"]+)"[^>]*>/g, (m, href) => {
  const f = resolveAsset(href);
  return f ? `<link rel="manifest" href="${dataUri(f)}">` : '';
});
html = html.replace(/<link[^>]+href="(\/icons\/[^"]+)"[^>]*>/g, (m, href) => {
  const f = resolveAsset(href);
  if (!f) return '';
  inlined.icons++;
  return m.replace(href, dataUri(f));
});

/* 6 ── sanity: no absolute /assets refs left */
const leftovers = html.match(/(?:src|href)="\/(?!manifest)[^"]*"/g) ?? [];
if (leftovers.length) console.warn('  ! leftover absolute refs:', leftovers.slice(0, 8));

writeFileSync(OUT, html);
const kb = (n) => (n / 1024).toFixed(0) + ' KB';
console.log(`[make-offline] ${OUT}`);
console.log(`  css×${inlined.css}  js×${inlined.js}  chunks×${inlined.chunks}  fonts/icons data-URIs×${inlined.fonts + inlined.icons}`);
console.log(`  size: ${kb(statSync(OUT).size)}  (assets dir total: ${kb(readdirSync(join(DIST, 'assets')).reduce((s, f) => s + statSync(join(DIST, 'assets', f)).size, 0))})`);
