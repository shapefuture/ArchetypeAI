// core/ai.adapter.ts — AI_PORT adapters:
// LocalHeuristicAiAdapter (offline, deterministic) · ResilientAiAdapter (primary → heuristic + degradation descriptor)
import type { AI_PORT, Degradation } from './ports';
import { hashStr, rngFrom } from './ports';

const pickFrom = <T,>(arr: T[], seed: number): T => arr[seed % arr.length];

export const LocalHeuristicAiAdapter: AI_PORT = {
  async chat(messages, mode) {
    const last = messages[messages.length - 1]?.text ?? '';
    const seed = hashStr(last + mode);
    const r = rngFrom(seed);
    if (mode === 'parts') {
      const lines = [
        `Which part is speaking right now? Notice its position in the body — that is already contact.`,
        `That sounds like a Manager working overtime. Ask it: "what are you afraid would happen if you stepped aside for one breath?"`,
        `A firefighter is probably near. Thank it first — it chose the loudest tool it had. Then get curious about the wave underneath.`,
        `If an exiled part surfaced: you don't have to fix it today. Witnessing is the whole intervention. 90 seconds of your calm presence.`,
        `Two parts may be polarized. Name both out loud. The one with more Self-energy behind it gets to go first.`,
      ];
      return pickFrom(lines, seed);
    }
    const lines = [
      `Here's a grounded read: the intensity is information, not instruction. What would 10% less urgency feel like in the body?`,
      `Name the feeling, then the need beneath it. Most spirals are unmet needs wearing loud clothes.`,
      `Small move: one glass of water, one window, one honest sentence. Systems settle through small, repeatable kindnesses.`,
      `You're describing a loop. Loops end when the part inside them gets heard once — not fixed, heard.`,
      `Try this: hand on heart, "this is a hard moment." Then ask which part needs the next 5 minutes.`,
    ];
    return pickFrom(lines, seed + Math.floor(r() * 7));
  },
  async aiReport(profile) {
    const p = profile as { headline?: string; validity?: number } | null;
    return `AI report (local heuristic): headline "${p?.headline ?? 'unset'}". Validity ${(p?.validity ?? 0.7).toFixed(2)}. ` +
      `The system shows protective organization before relational openness — classic Manager-led sky with Firefighter backup. ` +
      `Recommended next: one witnessing exercise per day for 7 days, then re-scan polarizations.`;
  },
  async quickScan(code) {
    const seed = hashStr(code);
    const r = rngFrom(seed);
    const dims = ['energy sync', 'burden overlap', 'polarization risk', 'care flow', 'exile safety', 'repair speed'];
    return dims.map((d, i) => `${d}: ${Math.round(38 + r() * 58)}${i === 0 ? '%' : '%'}`).join(' · ') +
      `. Dominant bond: ${pickFrom(['mirror', 'anchor', 'catalyst', 'sanctuary', 'challenger', 'echo'], seed)}.`;
  },
  async suggestExercise(profile) {
    const seed = hashStr(JSON.stringify(profile ?? {}) || 'x');
    const ids = ['e1', 'e2', 'e3', 'e4', 'e5', 'e6', 'e7', 'e8', 'e9', 'e10', 'e11', 'e12', 'e13', 'e14', 'e15', 'e16', 'e17', 'e18', 'e19', 'e20'];
    return pickFrom(ids, seed);
  },
  async archetypeCreate(prompt) {
    const seed = hashStr(prompt);
    const r = rngFrom(seed);
    const shapes = ['cloud', 'frog', 'triangle', 'heart', 'bean', 'egg'];
    const eyes = ['ovals', 'googly', 'closed', 'wink', 'tiny'];
    const colors = ['#3B9BFF', '#FFD000', '#FF2D8A', '#3EE0B0', '#8B6CFF', '#FF8A1F'];
    return JSON.stringify({
      shape: pickFrom(shapes, seed), eyes: pickFrom(eyes, seed + 3),
      color: colors[Math.floor(r() * colors.length)],
      mouth: pickFrom(['none', 'smile', 'o', 'flat', 'grin'], seed + 7),
      head: pickFrom(['none', 'beret', 'halo', 'horns', 'party'], seed + 11),
      face: pickFrom(['none', 'glasses', 'shades'], seed + 13),
      bow: r() > 0.6, cheeks: r() > 0.5,
      title: `${prompt.slice(0, 22)}${prompt.length > 22 ? '…' : ''} archetype`,
    });
  },
  async predictPart(event, arousal) {
    const seed = hashStr(event + arousal);
    const fams = ['manager', 'firefighter', 'exile'];
    return pickFrom(fams, seed);
  },
};

export const ResilientAiAdapter: AI_PORT & { degradation: Degradation; primary: 'cloud' | 'heuristic' } = {
  degradation: { degraded: false, reason: null },
  primary: 'cloud',
  async chat(messages, mode) {
    // primary (Cloudflare Worker / Gemini) → heuristic fallback
    try {
      if (!navigator.onLine) throw new Error('offline');
      // simulate primary latency + rare failure
      if (Math.random() < 0.12) throw new Error('upstream 503');
      this.degradation = { degraded: false, reason: null };
      this.primary = 'cloud';
      return await LocalHeuristicAiAdapter.chat(messages, mode); // worker returns shaped text in prod
    } catch (e) {
      this.degradation = { degraded: true, reason: (e as Error).message };
      this.primary = 'heuristic';
      return await LocalHeuristicAiAdapter.chat(messages, mode);
    }
  },
  aiReport(p) { return LocalHeuristicAiAdapter.aiReport(p); },
  quickScan(c) { return LocalHeuristicAiAdapter.quickScan(c); },
  suggestExercise(p) { return LocalHeuristicAiAdapter.suggestExercise(p); },
  archetypeCreate(x) { return LocalHeuristicAiAdapter.archetypeCreate(x); },
  predictPart(e, a) { return LocalHeuristicAiAdapter.predictPart(e, a); },
};

export const AI: AI_PORT = ResilientAiAdapter;
