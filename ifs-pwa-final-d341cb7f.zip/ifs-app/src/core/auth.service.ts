// core/auth.service.ts — AUTH_PORT impl (draft: core/adapters/firebase-auth.adapter.ts)
import type { AUTH_PORT, AuthUser } from './ports';
import { store, KEYS } from './local-store';

function mkUid() {
  return 'u_' + Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-4);
}
const persist = (u: AuthUser) => store.save(KEYS.auth, u);

export const auth: AUTH_PORT = {
  currentUser() { return store.load<AuthUser | null>(KEYS.auth, null); },

  async anonymousBootstrap() {
    const existing = auth.currentUser();
    if (existing) return existing;
    const u: AuthUser = { uid: mkUid(), email: null, provider: 'anonymous', linked: false };
    persist(u);
    return u;
  },

  async signInGoogle() {
    // Firebase popup w/ redirect fallback, simulated locally:
    const prev = auth.currentUser();
    const u: AuthUser = { uid: prev?.uid ?? mkUid(), email: 'you@gmail.com', provider: 'google', linked: true };
    persist(u); // UID preserved across anonymous→real upgrade
    return u;
  },

  async signInEmail(email: string) {
    const prev = auth.currentUser();
    const u: AuthUser = { uid: prev?.uid ?? mkUid(), email, provider: 'email', linked: true };
    persist(u);
    return u;
  },

  async linkAnonymous(email: string, provider: 'google' | 'email') {
    const prev = auth.currentUser() ?? (await auth.anonymousBootstrap());
    const u: AuthUser = { ...prev, email, provider, linked: true };
    persist(u);
    return u;
  },

  signOut() {
    const prev = auth.currentUser();
    const u: AuthUser = { uid: prev?.uid ?? mkUid(), email: null, provider: 'anonymous', linked: false };
    persist(u);
  },
};
