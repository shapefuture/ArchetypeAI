// core/billing.service.ts — BILLING_PORT (draft: services/billing.service.ts)
// Stripe checkout + verify, locale-mapped, cached verified flag.
import type { BILLING_PORT } from './ports';
import { store, KEYS } from './local-store';

type Interval = 'monthly' | 'yearly' | 'lifetime';
const PRICES: Record<string, Record<Interval, number>> = {
  USD: { monthly: 7.99, yearly: 49.99, lifetime: 89.99 },
  RUB: { monthly: 690, yearly: 4490, lifetime: 7990 },
};

let cachedPremium = store.load<string>(KEYS.billing, '') === 'premium';

export const billing: BILLING_PORT & { locale(): 'USD' | 'RUB' } = {
  locale() { return store.load('ifs.lang', 'en') === 'ru' ? 'RUB' : 'USD'; },
  plans() {
    const cur = this.locale();
    const p = PRICES[cur];
    return [
      { id: 'monthly', interval: 'monthly', price: p.monthly, currency: cur },
      { id: 'yearly', interval: 'yearly', price: p.yearly, currency: cur },
      { id: 'lifetime', interval: 'lifetime', price: p.lifetime, currency: cur },
    ];
  },
  async checkout(planId) {
    // Stripe-style: create session → confirm → verify webhook (simulated)
    await new Promise((r) => setTimeout(r, 900));
    const ok = ['monthly', 'yearly', 'lifetime'].includes(planId);
    if (ok) { store.save(KEYS.billing, 'premium'); cachedPremium = true; }
    return { ok, verified: ok };
  },
  isPremium() { return cachedPremium; },
  async restore() {
    const v = store.load<string>(KEYS.billing, '') === 'premium';
    cachedPremium = v;
    return v;
  },
};

export const setPremium = (on: boolean) => {
  store.save(KEYS.billing, on ? 'premium' : '');
  cachedPremium = on;
};
