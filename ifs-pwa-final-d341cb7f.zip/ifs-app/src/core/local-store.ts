// core/local-store.ts — STORAGE_PORT impl + Firestore-shaped mirror (draft: core/data/local-store.ts)
import type { STORAGE_PORT } from './ports';

const HIST_CAP = 30;
const mem: Record<string, string[]> = {};

export const store: STORAGE_PORT = {
  load<T>(key: string, fallback: T): T {
    try {
      const raw = localStorage.getItem(key);
      return raw ? (JSON.parse(raw) as T) : fallback;
    } catch { return fallback; }
  },
  save<T>(key: string, value: T) {
    try { localStorage.setItem(key, JSON.stringify(value)); } catch { /* quota */ }
    // localStorage mirror history (Firestore "latest + archive" shape)
    try {
      const h = mem[key] ?? (mem[key] = store.history<T>(key));
      const last = h[h.length - 1];
      const packed = JSON.stringify(value);
      if (last !== packed) {
        h.push(packed);
        if (h.length > HIST_CAP) h.shift();
        localStorage.setItem(`${key}.hist`, JSON.stringify(h));
      }
    } catch { /* ignore */ }
  },
  archive<T>(key: string, value: T) {
    try {
      const h = store.history<T>(key);
      h.push(JSON.stringify(value));
      if (h.length > HIST_CAP) h.shift();
      localStorage.setItem(`${key}.hist`, JSON.stringify(h));
    } catch { /* ignore */ }
  },
  history<T>(key: string): T[] {
    try {
      const raw = localStorage.getItem(`${key}.hist`);
      if (!raw) return [];
      (JSON.parse(raw) as string[]).forEach((p, i) => { (mem[key] ??= [])[i] = p; });
      return (JSON.parse(raw) as string[]).map((p) => JSON.parse(p) as T);
    } catch { return []; }
  },
  remove(key: string) {
    try { localStorage.removeItem(key); localStorage.removeItem(`${key}.hist`); } catch { /* ignore */ }
    delete mem[key];
  },
};

export const KEYS = {
  state: 'ifs.state',
  parts: 'ifs.parts',
  profile: 'ifs.profile',
  history: 'ifs.history',
  auth: 'ifs.auth',
  billing: 'ifs.billing',
  strings: 'ifs.lang',
  theme: 'ifs.theme',
  telemetry: 'ifs.telemetry',
  syn: 'ifs.syn.connections',
  share: 'ifs.share.codes',
  onboarded: 'ifs.onboarded',
  helpSeen: 'ifs.help.seen',
  installSeen: 'ifs.install.seen',
  charter: 'ifs.charter',
};
