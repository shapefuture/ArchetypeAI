// services/universe-scene.ts — three.js parts sky (draft: services/webxr.service.ts)
// Loaded via dynamic import on first Universe entry; sleep() on leave (context kept).
import * as THREE from 'three';
import type { Part } from '../pal/traits';

const FAMILY_COLOR: Record<string, string> = {
  manager: '#3B9BFF', firefighter: '#FF8A1F', exile: '#FF2D8A', resource: '#3EE0B0',
};

export interface UniverseAPI {
  wake(): void;
  sleep(): void;
  setParts(parts: Part[]): void;
  onPick(cb: (id: string) => void): void;
  resize(): void;
  dispose(): void;
}

let api: UniverseAPI | null = null;

export function initUniverse(host: HTMLElement, isDark: boolean): UniverseAPI {
  if (api) { api.resize(); return api; }

  const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
  renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
  renderer.setSize(host.clientWidth, host.clientHeight);
  host.appendChild(renderer.domElement);

  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(55, host.clientWidth / host.clientHeight, 0.1, 400);
  camera.position.set(0, 0, 46);

  // --- star dust ---
  const starGeo = new THREE.BufferGeometry();
  const N = 900;
  const pos = new Float32Array(N * 3);
  for (let i = 0; i < N; i++) {
    pos[i * 3] = (Math.random() - 0.5) * 220;
    pos[i * 3 + 1] = (Math.random() - 0.5) * 160;
    pos[i * 3 + 2] = (Math.random() - 0.5) * 220;
  }
  starGeo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  const stars = new THREE.Points(starGeo, new THREE.PointsMaterial({
    color: isDark ? 0xf4efe6 : 0x5a5470, size: 0.42, sizeAttenuation: true,
    transparent: true, opacity: isDark ? 0.85 : 0.55,
  }));
  scene.add(stars);

  // --- part bodies ---
  const partGroup = new THREE.Group();
  scene.add(partGroup);
  const meshes: THREE.Mesh[] = [];
  const labelTargets: { id: string; mesh: THREE.Mesh }[] = [];

  const geoCache = new Map<string, THREE.SphereGeometry>();
  const matCache = new Map<string, THREE.MeshStandardMaterial>();

  function build(parts: Part[]) {
    meshes.forEach((m) => { partGroup.remove(m); m.geometry.dispose(); });
    meshes.length = 0;
    labelTargets.length = 0;
    parts.forEach((p, i) => {
      const key = p.traits.shape;
      if (!geoCache.has(key)) {
        // slightly deformed spheres per shape family
        const g = new THREE.SphereGeometry(1.4, 26, 20);
        const pa = g.attributes.position as THREE.BufferAttribute;
        const w = key === 'triangle' ? 0.75 : key === 'heart' ? 0.9 : key === 'cloud' ? 1.15 : 1;
        for (let v = 0; v < pa.count; v++) {
          const y = pa.getY(v);
          const s = 1 + (w - 1) * (0.5 - y / 3);
          pa.setX(v, pa.getX(v) * s);
          if (key === 'egg' || key === 'bean') pa.setY(v, y * 1.25);
          if (key === 'heart') pa.setY(v, y - Math.abs(pa.getX(v)) * 0.28);
        }
        g.computeVertexNormals();
        geoCache.set(key, g);
      }
      const col = FAMILY_COLOR[p.family] ?? '#ffffff';
      if (!matCache.has(col)) {
        matCache.set(col, new THREE.MeshStandardMaterial({
          color: new THREE.Color(col), roughness: 0.5, metalness: 0.05,
          emissive: new THREE.Color(col).multiplyScalar(0.22),
        }));
      }
      const mesh = new THREE.Mesh(geoCache.get(key)!, matCache.get(col)!);
      const ring = i / Math.max(parts.length, 1);
      const rad = 14 + (i % 4) * 5.2;
      const ang = ring * Math.PI * 2 * 2.4;
      mesh.position.set(
        Math.cos(ang) * rad + (Math.random() - 0.5) * 4,
        Math.sin(ang * 0.7) * 9 + (Math.random() - 0.5) * 5,
        Math.sin(ang) * rad * 0.75 + (Math.random() - 0.5) * 4,
      );
      mesh.userData.partId = p.id;
      mesh.userData.baseY = mesh.position.y;
      mesh.userData.phase = Math.random() * Math.PI * 2;
      const sc = p.star ? 1.35 : 1;
      mesh.scale.setScalar(sc);
      partGroup.add(mesh);
      meshes.push(mesh);
      labelTargets.push({ id: p.id, mesh });
    });
  }

  // lights
  scene.add(new THREE.AmbientLight(0xffffff, isDark ? 0.55 : 0.9));
  const key = new THREE.DirectionalLight(0xfff3c4, isDark ? 1.4 : 1.1);
  key.position.set(12, 18, 20);
  scene.add(key);
  const rim = new THREE.PointLight(0x8b6cff, 60, 120);
  rim.position.set(-30, -10, -20);
  scene.add(rim);

  // interaction
  const ray = new THREE.Raycaster();
  const ndc = new THREE.Vector2();
  let pickCb: ((id: string) => void) | null = null;
  let running = true;
  let raf = 0;
  let t = 0;

  const onPointer = (e: PointerEvent) => {
    const rect = renderer.domElement.getBoundingClientRect();
    ndc.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    ndc.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
    ray.setFromCamera(ndc, camera);
    const hit = ray.intersectObjects(meshes, false)[0];
    if (hit && pickCb) pickCb(hit.object.userData.partId);
  };
  renderer.domElement.addEventListener('pointerdown', onPointer);

  let dragX = 0;
  renderer.domElement.addEventListener('pointermove', (e) => {
    if (e.buttons) dragX += e.movementX * 0.0035;
  });

  const onResize = () => {
    const w = host.clientWidth, h = host.clientHeight;
    camera.aspect = w / h; camera.updateProjectionMatrix();
    renderer.setSize(w, h);
  };
  addEventListener('resize', onResize);

  const loop = () => {
    if (!running) return;
    raf = requestAnimationFrame(loop);
    t += 0.006;
    partGroup.rotation.y = t * 0.55 + dragX;
    stars.rotation.y = t * 0.05;
    meshes.forEach((m) => {
      m.position.y = m.userData.baseY + Math.sin(t * 2 + m.userData.phase) * 0.7;
      m.rotation.y += 0.004;
    });
    renderer.render(scene, camera);
  };
  loop();

  api = {
    wake() { if (!running) { running = true; loop(); } },
    sleep() { running = false; cancelAnimationFrame(raf); },
    setParts: build,
    onPick(cb) { pickCb = cb; },
    resize: onResize,
    dispose() {
      running = false; cancelAnimationFrame(raf);
      removeEventListener('resize', onResize);
      renderer.domElement.removeEventListener('pointerdown', onPointer);
      renderer.dispose();
      renderer.domElement.remove();
      api = null;
    },
  };
  return api;
}
