import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

const NO_STORE = { 'Cache-Control': 'no-store' };

export default defineConfig({
  plugins: [react()],
  server: {
    host: true,
    port: 5174,
    allowedHosts: true,
    headers: NO_STORE, // draft: no-store on / and /index.html (dev)
  },
  preview: {
    host: true,
    port: 4174,
    allowedHosts: true,
    headers: NO_STORE, // draft: no-store on /, /index.html, /sw.js (prod preview)
  },
  build: {
    target: 'es2020',
    chunkSizeWarningLimit: 1400,
  },
});
